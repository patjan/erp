function display(the_message) {
	$('#jky-message').append('<br>' + the_message);
}
